package com.example.aggregatecalculator

class TeamClass(teamNameP: String, teamLeagueP: String, teamDivisionP: String){
    val teamName = teamNameP
    val teamLeague = teamLeagueP
    val teamDivision = teamDivisionP

}